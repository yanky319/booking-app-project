﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public static class Configuration
    {
        public static int serialGuestRequest = 10000000;
        public static double commision = 10;    //10 shekels -- zol meod
        public static int serialHostingUnit = 10000000;
    }
}
